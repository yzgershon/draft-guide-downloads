(() => {
  globalThis.createSentenceCueController = options => {
    const overlay = createSentenceCueOverlay();
    let session, tracker, active = false, shown = false, paused = false, composing = false;
    let hotkey = DraftGuideHotkey.DEFAULT, raf = 0, lastDraw = 0, saveTimer, starting = false;
    let lastKeyInput = { at: 0, text: '', type: '' };
    const attached = new WeakSet();
    const payload = () => session ? { offset: tracker.offset, revision: session.revision } : null;
    const progress = () => {
      clearTimeout(saveTimer); const value = payload();
      if (value) options.save(value).catch(e => options.status?.(e.message));
    };
    const deferSave = () => { clearTimeout(saveTimer); saveTimer = setTimeout(progress, 180); };
    const text = () => session ? SentenceCueModel.hintText(session.script, tracker.offset, session.settings.chunkSize, session.sentences) : '';
    const draw = () => {
      if (!active || !shown || paused || composing || session.settings.delivery === 'audio' || document.hidden || !document.hasFocus()) { overlay.hide(); return; }
      const anchor = options.anchor(); overlay.show(text(), anchor);
      if (!anchor) options.status?.('A reliable caret location is required. Click at your writing position and use the toggle key.');
    };
    const loop = now => {
      raf = 0; if (!active || !shown || paused) return;
      if (now - lastDraw > 80) { lastDraw = now; draw(); }
      raf = requestAnimationFrame(loop);
    };
    const refresh = () => { requestAnimationFrame(draw); if (active && shown && !paused && !raf) raf = requestAnimationFrame(loop); };
    const load = value => {
      session = value; tracker = SentenceCueModel.createTracker(value.script, value.offset);
      hotkey = value.settings.hotkey || DraftGuideHotkey.normalize({ key: value.settings.toggleKey }) || DraftGuideHotkey.DEFAULT; active = true; paused = false;
    };
    const stop = () => { progress(); active = false; shown = false; paused = false; overlay.hide(); cancelAnimationFrame(raf); raf = 0; options.stop?.(); };
    const suspend = () => {
      if (!active) return; progress(); paused = true; overlay.hide(); cancelAnimationFrame(raf); raf = 0;
      options.stop?.(); options.status?.('Tracking paused after navigation or an edit. Return to the writing position, then use the toggle key to resume.');
    };
    const toggle = async value => {
      if (starting) return;
      try {
        if (!active || paused) { starting = true; load(value || await options.start()); shown = true; }
        else shown = !shown;
        if (!shown) { overlay.hide(); options.stop?.(); }
        else if (session.settings.delivery !== 'visual') options.read?.({ ...payload(), text: text() });
        refresh();
      } catch (e) { options.status?.(e.message); }
      finally { starting = false; }
    };
    const consume = data => {
      if (!active || paused || !data) return;
      tracker.consume(data); deferSave(); refresh();
      options.status?.(tracker.mismatch ? 'The typed text differs from the template. Backspace to correct it; the template has not advanced.' : 'Following your typing.');
    };
    const backspace = () => { if (active && !paused) { tracker.backspace(); deferSave(); refresh(); } };
    const remember = (type, text, source = 'keydown') => { lastKeyInput = { at: performance.now(), type, text, source }; };
    const duplicate = (type, text) => lastKeyInput.type === type && SentenceCueModel.normalizeInput(lastKeyInput.text) === SentenceCueModel.normalizeInput(text) && performance.now() - lastKeyInput.at < 150;
    const attach = doc => {
      if (!doc || attached.has(doc)) return; attached.add(doc);
      doc.addEventListener('keydown', event => {
        if (!options.isEditor(event, doc)) return;
        if (!composing && DraftGuideHotkey.matches(event, hotkey)) {
          event.preventDefault(); event.stopImmediatePropagation(); if (!event.repeat) toggle(); return;
        }
        if (event.key === 'Escape') { stop(); return; }
        if (!active || paused || event.isComposing || composing) return;
        if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'PageUp', 'PageDown', 'Delete', 'Tab'].includes(event.key)) { suspend(); return; }
        if (event.ctrlKey || event.metaKey || event.altKey) {
          if (['z', 'y', 'x', 'v', 'a', 'backspace'].includes(event.key.toLowerCase())) suspend(); return;
        }
        if (event.key === 'Backspace') { remember('delete', ''); backspace(); }
        else if (event.key === 'Enter') { remember('insert', ' '); consume(' '); }
        else if ([...event.key].length === 1) { remember('insert', event.key); consume(event.key); }
      }, true);
      doc.addEventListener('beforeinput', event => {
        if (!options.isEditor(event, doc) || !active || paused || event.isComposing || composing) return;
        if (event.inputType === 'insertText' || event.inputType === 'insertFromComposition') {
          if (!duplicate('insert', event.data)) {
            // Prefer committed text when a keyboard event reports a different case or layout.
            if (lastKeyInput.source === 'keydown' && lastKeyInput.type === 'insert' && performance.now() - lastKeyInput.at < 150) tracker.backspace();
            consume(event.data);
          }
          remember('insert', event.data, 'beforeinput');
        } else if (['insertParagraph', 'insertLineBreak'].includes(event.inputType)) {
          if (!duplicate('insert', ' ')) consume(' ');
          remember('insert', ' ', 'beforeinput');
        } else if (event.inputType === 'deleteContentBackward') {
          if (!duplicate('delete', '')) backspace();
          remember('delete', '', 'beforeinput');
        } else if (!event.inputType?.includes('Composition')) suspend();
      }, true);
      doc.addEventListener('compositionstart', event => { if (options.isEditor(event, doc)) { composing = true; overlay.hide(); } }, true);
      doc.addEventListener('compositionend', event => {
        if (options.isEditor(event, doc)) { composing = false; consume(event.data); remember('insert', event.data, 'composition'); refresh(); }
      }, true);
      for (const type of ['paste', 'cut', 'drop']) doc.addEventListener(type, event => { if (options.isEditor(event, doc)) suspend(); }, true);
      doc.addEventListener('pointerdown', event => { if (options.isEditor(event, doc)) suspend(); }, true);
      for (const frame of doc.querySelectorAll('iframe')) { try { attach(frame.contentDocument); } catch {} }
      doc.addEventListener('load', event => { if (event.target.tagName === 'IFRAME') { try { attach(event.target.contentDocument); } catch {} } }, true);
    };
    attach(document);
    window.addEventListener('blur', () => overlay.hide());
    document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); });
    window.addEventListener('pagehide', progress);
    return {
      overlay, toggle, stop, suspend, position: payload,
      configure(settings) {
        hotkey = settings.hotkey || DraftGuideHotkey.normalize({ key: settings.toggleKey }) || DraftGuideHotkey.DEFAULT;
        if (session) session.settings = { ...session.settings, ...settings };
        refresh();
      },
      show(value) { load(value); shown = true; refresh(); },
      get visible() { return shown && active && !paused; }, get text() { return text(); }, get mismatch() { return !!tracker?.mismatch; }
    };
  };
})();
