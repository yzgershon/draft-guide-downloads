(() => {
  globalThis.createSentenceCueOverlay = () => {
    const host = document.createElement('sentence-cue-hint'); host.hidden = true;
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>
      :host{all:initial;position:fixed;display:block;z-index:2147483646;pointer-events:none!important;user-select:none!important;background:none!important;border:0!important;box-shadow:none!important;margin:0!important;padding:0!important;color:#9aa0a6;color-scheme:light}
      :host([hidden]){display:none!important}
      .ghost{display:block;white-space:pre-wrap;overflow-wrap:anywhere;margin:0;padding:0;border:0;background:none;pointer-events:none;user-select:none;color:inherit;font:inherit;line-height:inherit}
      @media print{:host{display:none!important}}
    </style><span class="ghost" aria-hidden="true"></span>`;
    document.documentElement.append(host);
    const ghost = root.querySelector('.ghost');
    return {
      host,
      hide() { host.hidden = true; ghost.textContent = ''; },
      show(text, anchor) {
        if (!text || !anchor || anchor.x < 0 || anchor.y < 0 || anchor.y > innerHeight - 5) { this.hide(); return; }
        const left = anchor.lineLeft ?? anchor.x;
        host.style.left = left + 'px'; host.style.top = anchor.y + 'px';
        host.style.width = Math.max(0, Math.min(anchor.right, innerWidth - 10) - left) + 'px';
        host.style.fontFamily = anchor.fontFamily || 'Arial, sans-serif';
        host.style.fontSize = (anchor.fontSize || 14.6667) + 'px'; host.style.lineHeight = (anchor.lineHeight || 20) + 'px';
        host.style.fontWeight = anchor.fontWeight || '400'; host.style.fontStyle = anchor.fontStyle || 'normal';
        ghost.style.textIndent = Math.max(0, anchor.x - left) + 'px';
        ghost.style.whiteSpace = anchor.lineLeft == null ? 'pre' : 'pre-wrap';
        host.style.overflow = 'hidden';
        host.style.maxHeight = anchor.lineLeft == null ? (anchor.lineHeight || 20) + 'px' : Math.max(20, innerHeight - anchor.y - 10) + 'px';
        ghost.textContent = text; host.hidden = false;
      },
      get visible() { return !host.hidden; }
    };
  };
})();
