(() => {
  // All geometry uses viewport CSS pixels. Chrome zoom / devicePixelRatio must
  // not be applied again: getBoundingClientRect already uses this coordinate space.
  globalThis.createDraftGuideAnchor = () => {
    let probe;
    const metrics = new Map();
    const fontBox = (font, lineHeight) => {
      const key = `${font}|${lineHeight}`;
      if (metrics.has(key)) return metrics.get(key);
      if (!probe) {
        probe = document.createElement('span');
        probe.setAttribute('aria-hidden', 'true');
        probe.style.cssText = 'all:initial;position:fixed;left:0;top:0;visibility:hidden;pointer-events:none;white-space:pre;display:block;width:max-content;';
        probe.textContent = 'Hg'; document.documentElement.append(probe);
        document.fonts?.addEventListener('loadingdone', () => metrics.clear());
      }
      probe.style.font = font; probe.style.lineHeight = `${lineHeight}px`;
      const range = document.createRange(); range.selectNodeContents(probe);
      const box = range.getBoundingClientRect(), outer = probe.getBoundingClientRect();
      const value = { height: box.height, top: box.top - outer.top };
      if (metrics.size > 100) metrics.clear();
      metrics.set(key, value); return value;
    };
    const controlText = id => {
      const control = document.getElementById(id);
      return control?.querySelector('input')?.value || control?.getAttribute('aria-valuetext') ||
        control?.querySelector('.goog-toolbar-menu-button-caption, .goog-toolbar-combo-button-caption')?.textContent || '';
    };
    return () => {
      const focused = document.activeElement;
      if (focused?.matches('input, textarea, [contenteditable="true"], button, [role="combobox"], [role="menuitem"]') && !focused.closest('.kix-appview-editor')) return null;
      const seen = new Set();
      const candidates = [...document.querySelectorAll('.kix-cursor-caret, .docs-text-ui-cursor-blink')].filter(element => {
        if (element.closest('.kix-cursor')?.querySelector('.kix-cursor-name')?.textContent.trim()) return false;
        const rect = element.getBoundingClientRect();
        if (rect.height < 4 || rect.width > 12 || rect.bottom < 0 || rect.top > innerHeight || getComputedStyle(element).display === 'none') return false;
        const key = `${Math.round(rect.left)}:${Math.round(rect.top)}`;
        if (seen.has(key)) return false; seen.add(key); return true;
      });
      if (candidates.length !== 1) return null;
      const caret = candidates[0], rect = caret.getBoundingClientRect();
      const pt = parseFloat(controlText('fontSizeSelect'));
      const fontFamily = controlText('fontFamilySelect').trim() || 'Arial';
      const fontWeight = document.querySelector('#boldButton')?.getAttribute('aria-pressed') === 'true' ? '700' : '400';
      const fontStyle = document.querySelector('#italicButton')?.getAttribute('aria-pressed') === 'true' ? 'italic' : 'normal';
      const font = size => `${fontStyle} ${fontWeight} ${size}px ${fontFamily}`;
      const zoomValue = controlText('zoomSelect') || controlText('zoomMenuButton');
      const percent = zoomValue.match(/(\d+(?:\.\d+)?)\s*%/);
      const transformScale = caret.offsetHeight ? rect.height / caret.offsetHeight : 1;
      const baseSize = pt > 0 ? pt * 4 / 3 : 14.6667;
      // Docs may resize its canvas/caret directly instead of applying a CSS transform.
      // A numeric Docs zoom value handles both. Fit modes fall back to measured geometry.
      let scale = percent ? Number(percent[1]) / 100 : transformScale;
      if (!percent && Math.abs(transformScale - 1) < 0.04) {
        const base = fontBox(font(baseSize), baseSize * 1.2);
        if (base.height) scale = rect.height / base.height;
      }
      scale = Math.min(10, Math.max(0.1, scale));
      const fontSize = baseSize * scale;
      const page = [...document.querySelectorAll('.kix-page')].find(p => { const r = p.getBoundingClientRect(); return r.left <= rect.left && r.right >= rect.right && r.top <= rect.top && r.bottom >= rect.bottom; });
      const line = [...(page || document).querySelectorAll('.kix-lineview')].find(p => { const r = p.getBoundingClientRect(); return r.width > 30 && r.top <= rect.top + 2 && r.bottom >= rect.bottom - 2 && r.left <= rect.left; });
      const lineRect = line?.getBoundingClientRect(), pageRight = page?.getBoundingClientRect().right || innerWidth - 16;
      const lineHeight = lineRect?.height || Math.max(rect.height, fontSize * 1.2);
      const measured = fontBox(font(fontSize), lineHeight);
      // Center the browser's actual font rectangle inside the caret's text rectangle.
      // Do not confuse font-size (the em square) with glyph/line-box height.
      const y = rect.top + (rect.height - measured.height) / 2 - measured.top;
      return { x: rect.left, y, right: lineRect?.right || pageRight - 24 * scale,
        lineLeft: lineRect?.left, fontFamily, fontSize, lineHeight, fontWeight, fontStyle };
    };
  };
})();
