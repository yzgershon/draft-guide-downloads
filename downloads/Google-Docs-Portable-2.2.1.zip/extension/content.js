(() => {
  if (globalThis.__sentenceCueInstalled || !/^\/document\/(?:u\/\d+\/)?d\//.test(location.pathname)) return;
  globalThis.__sentenceCueInstalled = true;
  const send = async message => {
    const result = await chrome.runtime.sendMessage(message);
    if (!result?.ok) throw new Error(result?.error || 'Reload this Google Doc after updating the extension.'); return result;
  };
  let lastStatus = '';
  const isEditor = (event, doc) => {
    if (doc !== document) { try { return !!doc.defaultView.frameElement?.matches('.docs-texteventtarget-iframe'); } catch { return false; } }
    return !!event.target.closest?.('.kix-appview-editor, .kix-page, .kix-cursor');
  };
  const anchor = createDraftGuideAnchor();
  const controller = createSentenceCueController({
    isEditor, anchor, start: async () => (await send({ type: 'session:start' })).session,
    save: position => send({ type: 'progress:save', ...position }),
    read: position => send({ type: 'speech:read', ...position }).catch(e => { lastStatus = e.message; }),
    stop: () => send({ type: 'speech:stop' }).catch(() => {}), status: message => { lastStatus = message; }
  });
  send({ type: 'config:get' }).then(data => controller.configure(data.settings)).catch(e => { lastStatus = e.message; });
  chrome.runtime.onMessage.addListener((message, _sender, respond) => {
    if (message.type === 'cue:toggle') controller.toggle(message.session);
    else if (message.type === 'cue:show') controller.show(message.session);
    else if (message.type === 'cue:stop') controller.stop();
    else if (message.type === 'cue:configure') { controller.configure(message.settings); controller.stop(); }
    else if (message.type === 'cue:preferences') controller.configure(message.settings);
    else if (message.type !== 'cue:position') return;
    respond({ ...controller.position(), visible: controller.visible, text: controller.text, mismatch: controller.mismatch, status: lastStatus });
  });
})();
