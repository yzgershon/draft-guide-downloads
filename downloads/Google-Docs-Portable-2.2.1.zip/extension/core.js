import './model.js';
import './hotkey.js';
export const Hotkey = globalThis.DraftGuideHotkey;
export const { hintText, createTracker } = globalThis.SentenceCueModel;
export const MAX_CHARS = 200000;
export const DEFAULT_SETTINGS = Object.freeze({ delivery: 'visual', chunkSize: 3, toggleKey: 'Insert', hotkey: Hotkey.DEFAULT, rate: 0.9, voiceName: '' });
export function settingsFrom(value = {}) {
  value ||= {};
  const choose = (key, choices) => choices.includes(value[key]) ? value[key] : DEFAULT_SETTINGS[key];
  const hotkey = Hotkey.normalize(value.hotkey) || Hotkey.normalize({ key: value.toggleKey }) || { ...Hotkey.DEFAULT };
  return { delivery: choose('delivery', ['visual', 'both', 'audio']), chunkSize: choose('chunkSize', [0, 1, 2, 3, 4, 5]),
    hotkey, toggleKey: Hotkey.format(hotkey),
    rate: Number.isFinite(value.rate) ? Math.min(1.4, Math.max(0.65, value.rate)) : DEFAULT_SETTINGS.rate,
    voiceName: typeof value.voiceName === 'string' ? value.voiceName.slice(0, 200) : '' };
}
export function updateSettings(state, patch) {
  const next = { ...state.settings };
  if (Object.hasOwn(patch, 'chunkSize')) {
    if (![0, 1, 2, 3, 4, 5].includes(patch.chunkSize)) throw new Error('Choose a word count or sentence.');
    next.chunkSize = patch.chunkSize;
  }
  if (Object.hasOwn(patch, 'hotkey')) {
    const hotkey = Hotkey.normalize(patch.hotkey);
    if (!hotkey) throw new Error('Record a valid shortcut first.');
    next.hotkey = hotkey;
  }
  return { ...state, settings: settingsFrom(next) };
}
export function splitCues(text) {
  if (typeof text !== 'string') throw new Error('Paste your reference text as plain text.');
  if (text.length > MAX_CHARS) throw new Error('Please keep the reference text under 200,000 characters.');
  const paragraphs = text.replace(/\r\n?/g, '\n').split(/\n+/).map(p => p.trim().replace(/\s+/gu, ' ')).filter(Boolean);
  const segmenter = new Intl.Segmenter('en', { granularity: 'sentence' });
  const cues = []; let start = 0;
  for (const [paragraph, clean] of paragraphs.entries()) {
    const sentences = [...segmenter.segment(clean)].map(s => s.segment.trim()).filter(Boolean);
    for (let i = 0; i < sentences.length - 1; i++) {
      if (/(?:\b(?:Mr|Mrs|Ms|Dr|Prof|Rev|Sr|Jr|St|vs|e\.g|i\.e)|\b[A-Z])\.$/u.test(sentences[i])) {
        sentences.splice(i, 2, sentences[i] + ' ' + sentences[i + 1]); i--;
      }
    }
    for (const [sentence, source] of sentences.entries()) {
      cues.push({ text: source, start, end: start + source.length, paragraph: paragraph + 1, sentence: sentence + 1 });
      start += source.length + 1;
    }
  }
  if (cues.length > 10000) throw new Error('Please use reference text with fewer than 10,000 sentences.');
  return cues;
}
export function emptyState() { return { version: 2, title: '', text: '', script: '', cues: [], offset: 0, index: 0, revision: 0, settings: { ...DEFAULT_SETTINGS } }; }
export function atOffset(state, offset) {
  offset = Number.isInteger(offset) ? Math.min(Math.max(0, offset), state.script.length) : 0;
  const found = state.cues.findIndex(c => c.end > offset);
  return { ...state, offset, index: found < 0 ? Math.max(0, state.cues.length - 1) : found };
}
export function normalizeState(value) {
  if (!value || typeof value !== 'object') return emptyState();
  const settings = settingsFrom(value.settings), text = typeof value.text === 'string' ? value.text.slice(0, MAX_CHARS) : '';
  const cues = splitCues(text), script = cues.map(c => c.text).join(' ');
  let offset = value.offset;
  if (value.version !== 2) offset = (value.cues || []).slice(0, value.index || 0).reduce((sum, cue) => sum + String(cue.text || '').length + 1, 0);
  return atOffset({ version: 2, title: typeof value.title === 'string' ? value.title.slice(0, 120) : '', text, script, cues,
    settings, revision: Number.isInteger(value.revision) ? value.revision : 0 }, offset);
}
export function saveDraft(previous, draft) {
  const cues = splitCues(draft.text);
  if (!cues.length) throw new Error('Paste reference text or import a text file first.');
  const state = { version: 2, title: String(draft.title || 'Untitled essay').trim().slice(0, 120), text: draft.text,
    script: cues.map(c => c.text).join(' '), cues, settings: settingsFrom(draft.settings), revision: previous.revision + 1 };
  return atOffset(state, previous.text === draft.text ? previous.offset : 0);
}
export function moveCue(state, direction) {
  const index = Math.min(Math.max(0, state.index + direction), Math.max(0, state.cues.length - 1));
  return atOffset({ ...state, revision: state.revision + 1 }, state.cues[index]?.start || 0);
}
export function cuePayload(state) {
  return { text: hintText(state.script, state.offset, state.settings.chunkSize, state.cues), index: state.index,
    total: state.cues.length, paragraph: state.cues[state.index]?.paragraph || 0, settings: state.settings, offset: state.offset };
}
export function sessionPayload(state) { return { script: state.script, sentences: state.cues, offset: state.offset, revision: state.revision, settings: state.settings }; }
export function isDocsUrl(url) {
  try { const u = new URL(url); return u.origin === 'https://docs.google.com' && /^\/document\/(?:u\/\d+\/)?d\//.test(u.pathname); } catch { return false; }
}
