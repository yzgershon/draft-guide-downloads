import { splitCues, emptyState, cuePayload, Hotkey } from './core.js';
import { request, isExtension, SAMPLE, demoSpeak } from './platform.js';
const $ = id => document.getElementById(id);
let state = emptyState(); let dirty = false;
const settingKeys = ['delivery', 'chunkSize', 'rate', 'voiceName'];
let chosenHotkey = { ...Hotkey.DEFAULT }, recording = false, shortcutPending = false, savingShortcut = false;
function renderShortcut(message = '') {
  $('shortcutValue').textContent = recording ? 'Press keys…' : Hotkey.format(chosenHotkey);
  $('recordLabel').textContent = recording ? 'Listening' : 'Change shortcut';
  $('recordShortcut').setAttribute('aria-pressed', String(recording));
  $('shortcutActions').hidden = !recording && !shortcutPending;
  $('saveShortcut').disabled = recording || !shortcutPending || savingShortcut;
  $('recordShortcut').disabled = savingShortcut;
  $('cancelShortcut').disabled = savingShortcut;
  $('shortcutStatus').textContent = message;
}
function cancelShortcut() {
  recording = false; shortcutPending = false; chosenHotkey = { ...state.settings.hotkey }; renderShortcut();
}
$('recordShortcut').addEventListener('click', () => {
  recording = true; renderShortcut('Press your shortcut now. Escape cancels.');
});
$('cancelShortcut').addEventListener('click', cancelShortcut);
document.addEventListener('keydown', event => {
  if (!recording) return;
  event.preventDefault(); event.stopImmediatePropagation();
  if (event.key === 'Escape') { cancelShortcut(); $('recordShortcut').focus(); return; }
  if (event.repeat) return;
  const result = Hotkey.capture(event);
  if (!result.hotkey) { renderShortcut(result.error); return; }
  chosenHotkey = result.hotkey; recording = false; shortcutPending = true;
  renderShortcut('Ready to save. Your current shortcut is unchanged until you save.');
}, true);
document.addEventListener('pointerdown', event => { if (recording && !$('shortcutRecorder').contains(event.target)) cancelShortcut(); }, true);
window.addEventListener('blur', () => { if (recording) cancelShortcut(); });
$('saveShortcut').addEventListener('click', async () => {
  if (recording || !shortcutPending || savingShortcut) return;
  savingShortcut = true; renderShortcut('Saving…');
  try {
    const data = await request({ type: 'settings:update', hotkey: chosenHotkey });
    state.settings = data.state.settings; chosenHotkey = { ...state.settings.hotkey }; shortcutPending = false;
    $('toggleKeyLabel').textContent = state.settings.toggleKey;
    renderShortcut('Shortcut saved. It is ready in your open documents.');
  } catch (e) { renderShortcut(e.message); }
  finally { savingShortcut = false; renderShortcut($('shortcutStatus').textContent); }
});
function tell(text, error = false) { $('status').textContent = text; $('status').classList.toggle('error', error); }
function words() { const n = $('essayText').value.trim().split(/\s+/u).filter(Boolean).length; $('wordCount').textContent = `${n.toLocaleString()} words`; }
function populate() {
  cancelShortcut();
  $('essayTitle').value = state.title; $('essayText').value = state.text;
  for (const key of settingKeys) $(key).value = String(state.settings[key]);
  $('rateValue').textContent = state.settings.rate.toFixed(2) + '×';
  dirty = false; $('saveState').textContent = state.cues.length ? 'Saved in this browser' : 'Nothing saved yet'; $('toggleKeyLabel').textContent = state.settings.toggleKey; words(); renderQueue();
}
function renderQueue() {
  $('cuePreview').textContent = cuePayload(state).text || (state.script ? 'Template complete.' : 'The next few words will appear here.');
  $('progress').textContent = state.cues.length ? `${state.index + 1} / ${state.cues.length}` : 'Not loaded';
  $('previousCue').disabled = !state.cues.length || state.index === 0;
  $('nextCue').disabled = !state.cues.length || state.index === state.cues.length - 1;
  $('queueCount').textContent = state.cues.length ? `${state.cues.length} sentences` : '';
  const fragment = document.createDocumentFragment();
  // Render a window for very long essays while still allowing any cue to be selected.
  const start = Math.max(0, state.index - 50); const end = Math.min(state.cues.length, start + 150);
  if (start > 0) fragment.append(queueButton(0, 'Go to the first sentence'));
  for (let i = start; i < end; i++) fragment.append(queueButton(i, state.cues[i].text));
  if (end < state.cues.length) fragment.append(queueButton(end, 'More sentences →'));
  $('cueList').replaceChildren(fragment);
}
function queueButton(index, text) {
  const li = document.createElement('li'); const button = document.createElement('button'); button.type = 'button';
  const n = document.createElement('span'); n.textContent = String(index + 1);
  button.append(n, document.createTextNode(text)); button.classList.toggle('selected', index === state.index);
  if (index === state.index) button.setAttribute('aria-current', 'step');
  button.addEventListener('click', () => jump(index)); li.append(button); return li;
}
async function jump(index) { try { state = (await request({ type: 'cue:jump', index })).state; renderQueue(); } catch (e) { tell(e.message, true); } }
function draft() {
  const settings = Object.fromEntries(settingKeys.map(key => [key, ['chunkSize', 'rate'].includes(key) ? Number($(key).value) : $(key).value]));
  settings.hotkey = chosenHotkey;
  return { title: $('essayTitle').value, text: $('essayText').value, settings };
}
$('essayForm').addEventListener('input', () => { dirty = true; tell(''); $('saveState').textContent = 'Unsaved changes'; words(); $('rateValue').textContent = Number($('rate').value).toFixed(2) + '×'; });
$('delivery').addEventListener('change', () => { if ($('delivery').value !== 'visual') $('audioDetails').open = true; });
$('essayForm').addEventListener('submit', async event => {
  event.preventDefault(); $('saveButton').disabled = true;
  try { const data = draft(); splitCues(data.text, data.settings.chunkSize); state = (await request({ type: 'essay:save', draft: data })).state; populate(); tell(`${state.cues.length} sentences saved. Reload your Google Doc after updating, click your writing position, then press ${state.settings.toggleKey}.`); }
  catch (e) { tell(e.message, true); }
  finally { $('saveButton').disabled = false; }
});
$('importButton').addEventListener('click', () => $('fileInput').click());
$('fileInput').addEventListener('change', async event => {
  const file = event.target.files[0]; if (!file) return;
  try {
    if (!/\.(txt|md)$/i.test(file.name)) throw new Error('Import a .txt or .md file, or paste text from your document.');
    if (file.size > 800000) throw new Error('That file is too large. Please paste an essay under 200,000 characters.');
    const text = await file.text(); splitCues(text);
    $('essayText').value = text; $('essayTitle').value = file.name.replace(/\.[^.]+$/, '');
    dirty = true; $('saveState').textContent = 'Unsaved changes'; words(); tell('Text imported. Save to load your reference.');
  } catch (e) { tell(e.message, true); } finally { event.target.value = ''; }
});
$('sampleButton').addEventListener('click', () => {
  if ($('essayText').value.trim() && $('essayText').value !== SAMPLE) { tell('Clear the text box first if you want to replace it with the sample.', true); return; }
  $('essayTitle').value = 'On writing a good essay'; $('essayText').value = SAMPLE; dirty = true; words(); $('saveState').textContent = 'Unsaved changes'; tell('Sample loaded. Save to try the reference.');
});
$('previousCue').addEventListener('click', () => jump(state.index - 1));
$('nextCue').addEventListener('click', () => jump(state.index + 1));
$('clearButton').addEventListener('click', () => { $('clearConfirm').hidden = false; });
$('cancelClear').addEventListener('click', () => { $('clearConfirm').hidden = true; });
$('confirmClear').addEventListener('click', async () => { try { state = (await request({ type: 'essay:clear' })).state; populate(); $('clearConfirm').hidden = true; tell('Saved reference cleared.'); } catch (e) { tell(e.message, true); } });
$('testVoice').addEventListener('click', async () => {
  try {
    if (dirty) throw new Error('Save your reference and voice settings first.');
    if (isExtension) await request({ type: 'voice:test' });
    else await demoSpeak('This is your selected voice. Check your earbud.', state.settings.rate);
    tell('Voice test requested. Speech uses your system’s selected audio output.');
  } catch (e) { tell(e.message, true); }
});
$('stopVoice').addEventListener('click', async () => { try { await request({ type: 'cue:action', action: 'stop' }); tell('Speech stopped.'); } catch (e) { tell(e.message, true); } });
window.addEventListener('beforeunload', event => { if (dirty || shortcutPending) { event.preventDefault(); event.returnValue = ''; } });
async function load() {
  $('previewNotice').hidden = isExtension;
  try {
    const data = await request({ type: 'state:get' }); state = data.state;
    const { voices } = await request({ type: 'voices:get' });
    for (const voice of voices) { const option = document.createElement('option'); option.value = voice.voiceName; option.textContent = `${voice.voiceName}${voice.lang ? ' · ' + voice.lang : ''}`; $('voiceName').append(option); }
    if (state.settings.voiceName && !voices.some(v => v.voiceName === state.settings.voiceName)) { const option = new Option(`${state.settings.voiceName} (unavailable; automatic fallback)`, state.settings.voiceName); $('voiceName').append(option); }
    $('voiceNote').textContent = isExtension ? (voices.length ? `${voices.length} local voices available. Save settings before testing.` : 'No local voice reported yet. Reopen this page after installing a system speech voice.') : 'Chrome extension voices are available after installation. This preview uses local browser voices if available.';
    populate(); if (data.lastError) tell(data.lastError, true);
  } catch (e) { tell(e.message, true); }
}
load();
