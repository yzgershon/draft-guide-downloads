import { request, isExtension } from './platform.js';
const $ = id => document.getElementById(id);
let state;
const error = message => { $('popupError').textContent = message; $('popupError').hidden = !message; };
function render(value) {
  state = value; $('chunkSize').value = String(state.settings.chunkSize);
  $('keyHint').textContent = state.cues.length ? `${state.settings.toggleKey} · toggle` : 'Add reference text in Settings';
}
$('chunkSize').addEventListener('change', async () => {
  const chunkSize = Number($('chunkSize').value);
  $('chunkSize').disabled = true; $('saveStatus').textContent = ''; error('');
  try { render((await request({ type: 'settings:update', chunkSize })).state); $('saveStatus').textContent = 'Saved'; }
  catch (e) { if (state) render(state); error(e.message); }
  finally { $('chunkSize').disabled = false; }
});
$('setupLink').addEventListener('click', event => {
  if (!isExtension) return;
  event.preventDefault(); chrome.runtime.openOptionsPage(); window.close();
});
try {
  const data = await request({ type: 'state:get' }); render(data.state);
  $('chunkSize').disabled = false; error(data.lastError || '');
} catch (e) { error(e.message); }
