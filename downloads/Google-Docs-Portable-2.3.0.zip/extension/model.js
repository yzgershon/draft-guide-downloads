(() => {
  const equivalent = c => /\s/u.test(c) ? ' ' : c.replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/[–—]/g, '-');
  function hintText(script, offset, amount = 3, sentences = []) {
    if (offset >= script.length) return '';
    if (amount === 0) return script.slice(offset, sentences.find(c => c.end > offset)?.end ?? script.length);
    const rest = script.slice(offset), words = [];
    for (const word of rest.matchAll(/\S+/gu)) { words.push(word); if (words.length === amount) break; }
    return words.length ? rest.slice(0, words.at(-1).index + words.at(-1)[0].length) : rest;
  }
  function createTracker(script, initialOffset = 0) {
    let offset = Math.max(0, Math.min(script.length, initialOffset)), pending = '';
    const history = [];
    return {
      get offset() { return offset; }, get mismatch() { return pending.length > 0; },
      consume(text) {
        for (const char of text) {
          history.push({ offset, pending }); if (history.length > 5000) history.shift();
          const expected = offset < script.length ? String.fromCodePoint(script.codePointAt(offset)) : '';
          if (!pending && expected && equivalent(char) === equivalent(expected)) offset += expected.length;
          else if (!pending && /\s/u.test(char) && offset > 0 && /\s/u.test(script[offset - 1])) { /* Equivalent repeated whitespace. */ }
          else pending += char;
        }
        return offset;
      },
      backspace() {
        const prior = history.pop();
        if (prior) { offset = prior.offset; pending = prior.pending; }
        else if (pending) pending = [...pending].slice(0, -1).join('');
        else if (offset) offset -= [...script.slice(0, offset)].at(-1).length;
        return offset;
      }
    };
  }
  const normalizeInput = text => [...String(text ?? '')].map(equivalent).join('');
  globalThis.SentenceCueModel = { createTracker, hintText, normalizeInput };
})();
