(() => {
  const DEFAULT = Object.freeze({ key: 'Insert', code: '', ctrl: false, alt: false, shift: false, meta: false });
  const singleKeys = new Set(['Insert', 'Home', 'End', 'PageUp', 'PageDown', 'Pause', 'ScrollLock']);
  const modifiedKeys = new Set([...singleKeys, 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Enter', ' ', 'Tab', 'Backspace', 'Delete']);
  const modifiers = new Set(['Control', 'Alt', 'Shift', 'Meta', 'AltGraph', 'Fn', 'FnLock']);
  const keyName = key => ({ ' ': 'Space', Control: 'Ctrl', Meta: 'Cmd', ArrowLeft: 'Left', ArrowRight: 'Right', ArrowUp: 'Up', ArrowDown: 'Down', PageUp: 'Page Up', PageDown: 'Page Down', ScrollLock: 'Scroll Lock' }[key] || ([...key].length === 1 ? key.toUpperCase() : key));
  function normalize(value) {
    if (!value || typeof value !== 'object' || typeof value.key !== 'string') return null;
    const key = value.key === 'Spacebar' ? ' ' : value.key;
    const combo = value.ctrl === true || value.alt === true || value.meta === true, fn = /^F(?:[1-9]|1\d|2[0-4])$/.test(key);
    if (!(fn || (combo ? modifiedKeys.has(key) || [...key].length === 1 : singleKeys.has(key)))) return null;
    // Browser/window actions cannot reliably be intercepted by content scripts.
    if ((value.ctrl || value.meta) && ['w', 't', 'n', 'l', 'r', 'q'].includes(key.toLowerCase())) return null;
    if ((value.ctrl || value.meta) && value.shift && (/^Digit[1-4]$/.test(value.code || '') || /^[1-4!@#$]$/.test(key))) return null;
    if (value.alt && ['F4', 'Tab', 'Escape'].includes(key)) return null;
    return { key, code: typeof value.code === 'string' && /^[A-Za-z][A-Za-z0-9]{0,39}$/.test(value.code) ? value.code : '',
      ctrl: value.ctrl === true, alt: value.alt === true, shift: value.shift === true, meta: value.meta === true };
  }
  function format(value) {
    const h = normalize(value) || DEFAULT;
    return [h.ctrl && 'Ctrl', h.alt && 'Alt', h.shift && 'Shift', h.meta && 'Cmd', keyName(h.key)].filter(Boolean).join(' + ');
  }
  function capture(event) {
    if (event.isComposing || event.key === 'Dead' || event.key === 'Process' || event.getModifierState?.('AltGraph')) return { error: 'Finish text input, then choose a shortcut without AltGr.' };
    if (modifiers.has(event.key)) return { error: 'Keep the modifier held and press another key.' };
    const hotkey = normalize({ key: event.key, code: event.code, ctrl: event.ctrlKey, alt: event.altKey, shift: event.shiftKey, meta: event.metaKey });
    return hotkey ? { hotkey } : { error: 'Choose a function/navigation key, or add Ctrl, Alt, or Cmd. Typing keys and reserved shortcuts are unavailable.' };
  }
  function matches(event, value) {
    const h = normalize(value) || DEFAULT;
    if (event.isComposing || event.getModifierState?.('AltGraph')) return false;
    return !!event.ctrlKey === h.ctrl && !!event.altKey === h.alt && !!event.shiftKey === h.shift && !!event.metaKey === h.meta &&
      (h.code && event.code ? h.code === event.code : event.key?.toLowerCase() === h.key.toLowerCase());
  }
  globalThis.DraftGuideHotkey = { DEFAULT, normalize, format, capture, matches };
})();
