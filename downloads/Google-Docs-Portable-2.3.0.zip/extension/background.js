import { emptyState, normalizeState, saveDraft, updateSettings, moveCue, atOffset, cuePayload, sessionPayload, isDocsUrl } from './core.js';
let chain = Promise.resolve(), speechId = 0;
const serialize = task => { const result = chain.then(task); chain = result.catch(() => {}); return result; };
const getState = async () => normalizeState((await chrome.storage.local.get('essay')).essay);
const putState = state => chrome.storage.local.set({ essay: state });
const status = error => chrome.storage.session.set({ lastError: error || '' });
chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(() => {});
const stopSpeech = () => { speechId++; chrome.tts.stop(); };
async function broadcast(type, data = {}) {
  await Promise.all((await chrome.tabs.query({})).map(tab => chrome.tabs.sendMessage(tab.id, { type, ...data }, { frameId: 0 }).catch(() => {})));
}
async function speak(state) {
  stopSpeech(); const id = speechId, text = cuePayload(state).text;
  if (!text.trim()) return;
  const voices = (await chrome.tts.getVoices()).filter(v => v.remote === false);
  const voice = voices.find(v => v.voiceName === state.settings.voiceName) || voices.find(v => /^en(?:-|$)/i.test(v.lang || '')) || voices[0];
  if (!voice) throw new Error('No local speech voice is available. Install a system speech voice, then reopen Chrome.');
  if (id !== speechId) return;
  await chrome.tts.speak(text, {
    voiceName: voice.voiceName, ...(voice.lang ? { lang: voice.lang } : {}), ...(voice.extensionId ? { extensionId: voice.extensionId } : {}),
    rate: state.settings.rate, enqueue: false,
    onEvent: event => { if (id === speechId && event.type === 'error') status(event.errorMessage || 'Speech could not start. Check your voice and audio output.'); }
  });
}
async function owner(tabId) { await chrome.storage.session.set({ ownerTabId: tabId }); }
async function saveProgress(tabId, data) {
  const state = await getState();
  if (data.revision !== state.revision || (await chrome.storage.session.get('ownerTabId')).ownerTabId !== tabId) return state;
  if (!Number.isInteger(data.offset) || data.offset < 0 || data.offset > state.script.length) throw new Error('Invalid template position.');
  const next = atOffset(state, data.offset); if (state.offset !== next.offset) await putState(next); return next;
}
async function readPosition(tabId) {
  try { const position = await chrome.tabs.sendMessage(tabId, { type: 'cue:position' }, { frameId: 0 }); return await saveProgress(tabId, position); }
  catch { return getState(); }
}
async function ensureContent(tab) {
  if (!tab?.id || !isDocsUrl(tab.url)) return { connected: false };
  const ping = () => chrome.tabs.sendMessage(tab.id, { type: 'cue:ping' }, { frameId: 0 });
  let connection;
  try { connection = await ping(); } catch {}
  if (connection?.version !== chrome.runtime.getManifest().version && !connection?.needsReload) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: chrome.runtime.getManifest().content_scripts[0].js });
      connection = await ping();
    } catch {
      throw new Error('Could not connect to this document. Check this extension’s Google Docs site access in Chrome, then reload the document. A managed browser may restrict access.');
    }
  }
  if (connection?.needsReload) throw new Error('Reload this document once to finish updating the older extension.');
  if (!connection?.ready) throw new Error('The document is still loading. Click the editor and reopen this popup to retry.');
  return { connected: true };
}
async function command(name, tab) {
  if (name === 'stop') { stopSpeech(); await broadcast('cue:stop'); return {}; }
  if (!tab?.id || !isDocsUrl(tab.url)) throw new Error('Open a Google Docs document to use hints.');
  await ensureContent(tab);
  let state = await readPosition(tab.id);
  if (!state.cues.length) throw new Error('Load reference text first in Reference & settings.');
  await owner(tab.id);
  if (name === 'next' || name === 'previous') { state = moveCue(state, name === 'next' ? 1 : -1); await putState(state); }
  if (name === 'read') { await speak(state); return { state }; }
  try {
    await chrome.tabs.sendMessage(tab.id, { type: name === 'toggle' ? 'cue:toggle' : 'cue:show', session: sessionPayload(state) }, { frameId: 0 });
  } catch { throw new Error('Reload this Google Doc once after updating the extension, then press ' + state.settings.toggleKey + '.'); }
  return { state };
}
chrome.commands.onCommand.addListener((name, tab) => {
  serialize(async () => { await status(''); await command(name, tab || (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0]); }).catch(e => status(e.message));
});
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!message || sender.id !== chrome.runtime.id) return;
  const fromPage = !sender.url?.startsWith(chrome.runtime.getURL(''));
  const pageTypes = ['config:get', 'session:start', 'progress:save', 'speech:read', 'speech:stop'];
  if (fromPage && (!isDocsUrl(sender.tab?.url) || sender.frameId !== 0 || !pageTypes.includes(message.type))) return;
  serialize(async () => {
    if (message.type === 'config:get') return { settings: (await getState()).settings };
    if (message.type === 'session:start') {
      const state = await getState(); if (!state.script) throw new Error('Load and save reference text in the extension settings first.');
      await owner(sender.tab.id); await status(''); return { session: sessionPayload(state) };
    }
    if (message.type === 'progress:save') { await saveProgress(sender.tab.id, message); return {}; }
    if (message.type === 'speech:stop') { stopSpeech(); return {}; }
    if (message.type === 'speech:read') {
      const state = await saveProgress(sender.tab.id, message);
      if (message.revision === state.revision && (await chrome.storage.session.get('ownerTabId')).ownerTabId === sender.tab.id) await speak(state);
      return {};
    }
    if (message.type === 'state:get') return { state: await getState(), lastError: (await chrome.storage.session.get('lastError')).lastError || '' };
    if (message.type === 'document:connect') {
      const connection = await ensureContent((await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0]);
      if (connection.connected) await status('');
      return connection;
    }
    if (message.type === 'voices:get') return { voices: (await chrome.tts.getVoices()).filter(v => v.remote === false) };
    if (message.type === 'settings:update') {
      const state = updateSettings(await getState(), message);
      await putState(state); await broadcast('cue:preferences', { settings: state.settings });
      return { state };
    }
    if (message.type === 'essay:save') {
      const state = saveDraft(await getState(), message.draft); await putState(state); stopSpeech();
      await broadcast('cue:configure', { settings: state.settings }); await status(''); return { state };
    }
    if (message.type === 'essay:clear') {
      const previous = await getState(), state = { ...emptyState(), revision: previous.revision + 1 };
      await putState(state); stopSpeech(); await broadcast('cue:configure', { settings: state.settings }); await status(''); return { state };
    }
    if (message.type === 'cue:jump') {
      let state = await getState();
      if (!Number.isInteger(message.index) || message.index < 0 || message.index >= state.cues.length) throw new Error('Choose a sentence in the list.');
      state = atOffset({ ...state, revision: state.revision + 1 }, state.cues[message.index].start);
      await putState(state); stopSpeech(); await broadcast('cue:stop'); return { state };
    }
    if (message.type === 'voice:test') {
      const state = saveDraft(await getState(), { title: '', text: 'This is your selected voice. Check your earbud.', settings: { ...(await getState()).settings, chunkSize: 0 } });
      await speak(state); return {};
    }
    if (message.type === 'cue:action') { await status(''); return command(message.action, (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0]); }
    throw new Error('Unknown action.');
  }).then(data => respond({ ok: true, ...data })).catch(async e => { await status(e.message); respond({ ok: false, error: e.message }); });
  return true;
});
// A delayed tab-focus event must not stop a session just started in the new tab.
// Stop only the previous owner; the hidden document also stops itself immediately.
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  const { ownerTabId } = await chrome.storage.session.get('ownerTabId');
  if (ownerTabId && ownerTabId !== tabId) {
    stopSpeech(); chrome.tabs.sendMessage(ownerTabId, { type: 'cue:stop' }, { frameId: 0 }).catch(() => {});
  }
});
chrome.windows.onFocusChanged.addListener(async () => {
  try {
    const { ownerTabId } = await chrome.storage.session.get('ownerTabId');
    if (!ownerTabId) return;
    const [tab, focused] = await Promise.all([chrome.tabs.get(ownerTabId), chrome.windows.getLastFocused()]);
    if (!focused.focused || focused.id !== tab.windowId) {
      stopSpeech(); await chrome.tabs.sendMessage(ownerTabId, { type: 'cue:stop' }, { frameId: 0 });
    }
  } catch {}
});
