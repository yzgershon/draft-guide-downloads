(() => {
  const version = chrome.runtime.getManifest().version;
  const previous = globalThis.__sentenceCueInstalled;
  if (previous?.version === version) { previous.refresh(); return; }
  // Old builds did not expose a disposer. Do not layer a second typing listener
  // over them; a one-time page refresh completes that upgrade safely.
  if (previous === true) {
    chrome.runtime.onMessage.addListener((message, _sender, respond) => {
      if (message.type === 'cue:ping') respond({ needsReload: true });
    });
    return;
  }
  previous?.dispose?.();
  let controller, route = '', lastStatus = '', configured = false, configuring = false, disposed = false;
  const anchor = createDraftGuideAnchor();
  const validContext = () => { try { return !!chrome.runtime.id; } catch { return false; } };
  const send = async message => {
    if (!validContext()) { dispose(); throw new Error('Open the extension popup to reconnect this document.'); }
    const result = await chrome.runtime.sendMessage(message);
    if (!result?.ok) throw new Error(result?.error || 'Open the extension popup to check this document connection.');
    return result;
  };
  const isEditor = (event, doc) => {
    if (doc !== document) { try { return !!doc.defaultView.frameElement?.matches('.docs-texteventtarget-iframe'); } catch { return false; } }
    return !!event.target.closest?.('.kix-appview-editor, .kix-page, .kix-cursor');
  };
  const configure = () => {
    if (!controller || configured || configuring) return;
    configuring = true; const current = controller;
    send({ type: 'config:get' }).then(data => {
      if (controller === current && !disposed) { current.configure(data.settings); configured = true; }
    }).catch(e => { lastStatus = e.message; }).finally(() => { configuring = false; });
  };
  const refresh = () => {
    if (disposed) return;
    if (!validContext()) { dispose(); return; }
    const next = location.pathname.match(/^\/document\/(?:u\/\d+\/)?d\/([^/]+)/)?.[0] || '';
    if (next !== route) {
      controller?.dispose(); controller = null; route = next; configured = false; lastStatus = '';
      if (route) controller = createSentenceCueController({
        isEditor, anchor, frameSelector: 'iframe.docs-texteventtarget-iframe',
        start: async () => (await send({ type: 'session:start' })).session,
        save: position => send({ type: 'progress:save', ...position }),
        read: position => send({ type: 'speech:read', ...position }).catch(e => { lastStatus = e.message; }),
        stop: () => send({ type: 'speech:stop' }).catch(() => {}), status: message => { lastStatus = message; }
      });
    }
    controller?.rescan(); configure();
  };
  const onMessage = (message, _sender, respond) => {
    refresh();
    if (message.type === 'cue:ping') { respond({ version, ready: !!controller, status: lastStatus }); return; }
    if (!controller) return;
    if (message.type === 'cue:toggle') controller.toggle(message.session);
    else if (message.type === 'cue:show') controller.show(message.session);
    else if (message.type === 'cue:stop') controller.stop();
    else if (message.type === 'cue:configure') { controller.configure(message.settings); controller.stop(); }
    else if (message.type === 'cue:preferences') controller.configure(message.settings);
    else if (message.type !== 'cue:position') return;
    respond({ ...controller.position(), visible: controller.visible, text: controller.text, mismatch: controller.mismatch, status: lastStatus });
  };
  function dispose() {
    if (disposed) return;
    disposed = true; clearInterval(timer); window.removeEventListener('popstate', refresh);
    window.removeEventListener('pageshow', refresh); controller?.dispose(); controller = null;
    try { chrome.runtime.onMessage.removeListener(onMessage); } catch {}
    if (globalThis.__sentenceCueInstalled?.version === version) delete globalThis.__sentenceCueInstalled;
  }
  const timer = setInterval(refresh, 1000);
  globalThis.__sentenceCueInstalled = { version, refresh, dispose };
  chrome.runtime.onMessage.addListener(onMessage);
  window.addEventListener('popstate', refresh); window.addEventListener('pageshow', refresh);
  refresh();
})();
