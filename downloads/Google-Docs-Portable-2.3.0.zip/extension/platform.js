import { emptyState, normalizeState, saveDraft, updateSettings, moveCue, atOffset, sessionPayload } from './core.js';
export const isExtension = location.protocol === 'chrome-extension:';
export const SAMPLE = 'A good essay begins with a question worth asking. The strongest introduction gives the reader a reason to care, then makes a clear claim.\n\nEach paragraph should develop one idea. Evidence matters, but explanation is what connects that evidence to the argument. Before moving on, ask what the reader now understands that they did not understand before.\n\nA conclusion returns to the central question with a more thoughtful answer. It should leave the reader with something to consider.';
let demo = readDemo();
function localStorageSafeGet() { if (isExtension) return null; try { return localStorage.getItem('sentence-cue-preview'); } catch { return null; } }
function readDemo() { try { return normalizeState(JSON.parse(localStorageSafeGet() || 'null')); } catch { return emptyState(); } }
function persist() { localStorage.setItem('sentence-cue-preview', JSON.stringify(demo)); }
export async function request(message) {
  if (isExtension) {
    const response = await chrome.runtime.sendMessage(message);
    if (!response?.ok) throw new Error(response?.error || 'The extension did not respond. Reload it from chrome://extensions.');
    return response;
  }
  demo = readDemo();
  if (message.type === 'state:get') return { state: demo, lastError: '' };
  if (message.type === 'session:start') return { session: sessionPayload(demo) };
  if (message.type === 'config:get') return { settings: demo.settings };
  if (message.type === 'voices:get') return { voices: [] };
  if (message.type === 'essay:save') demo = saveDraft(demo, message.draft);
  else if (message.type === 'settings:update') demo = updateSettings(demo, message);
  else if (message.type === 'essay:clear') demo = emptyState();
  else if (message.type === 'cue:jump') demo = atOffset({ ...demo, revision: demo.revision + 1 }, demo.cues[message.index]?.start || 0);
  else if (message.type === 'progress:save' && message.revision === demo.revision) demo = atOffset(demo, message.offset);
  else if (message.type === 'cue:action') {
    if (message.action === 'next') demo = moveCue(demo, 1);
    if (message.action === 'previous') demo = moveCue(demo, -1);
    if (message.action === 'stop') speechSynthesis.cancel();
  }
  persist();
  return { state: demo };
}
export async function demoSpeak(text, rate = 0.9) {
  speechSynthesis.cancel();
  const voices = speechSynthesis.getVoices().filter(v => v.localService);
  const voice = voices.find(v => /^en/i.test(v.lang)) || voices[0];
  if (!voice) throw new Error('No local voice is available in this preview browser. Test read-aloud in the installed Chrome extension.');
  const utterance = new SpeechSynthesisUtterance(text); utterance.voice = voice; utterance.rate = rate;
  speechSynthesis.speak(utterance);
}
