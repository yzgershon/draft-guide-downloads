import { emptyState, sessionPayload } from './core.js';
import { request, isExtension, SAMPLE, demoSpeak } from './platform.js';
let state = emptyState();
const status = document.getElementById('practiceStatus'), editor = document.querySelector('[contenteditable]');
const select = document.getElementById('practiceAmount');
function focusEditor() {
  editor.focus(); const selection = getSelection();
  if (!selection.rangeCount || !editor.contains(selection.anchorNode)) { const range = document.createRange(); range.selectNodeContents(editor); range.collapse(false); selection.removeAllRanges(); selection.addRange(range); }
}
function anchor() {
  const selection = getSelection(); if (!selection.rangeCount || !selection.isCollapsed || !editor.contains(selection.anchorNode)) return null;
  const range = selection.getRangeAt(0).cloneRange(); range.collapse(true);
  const box = editor.getBoundingClientRect(), style = getComputedStyle(editor);
  const rect = [...range.getClientRects()].find(r => r.height > 0);
  const lineHeight = parseFloat(style.lineHeight), fontSize = parseFloat(style.fontSize);
  return { x: rect?.left ?? box.left, y: rect ? rect.top - (lineHeight - rect.height) / 2 : box.top,
    lineLeft: box.left, right: box.right, lineHeight, fontSize, fontFamily: style.fontFamily };
}
const controller = createSentenceCueController({
  anchor, isEditor: event => event.target === editor || editor.contains(event.target),
  start: async () => (await request({ type: 'session:start' })).session,
  save: position => request({ type: 'progress:save', ...position }),
  read: async position => { try { if (isExtension) await request({ type: 'speech:read', ...position }); else await demoSpeak(position.text, state.settings.rate); } catch (e) { status.textContent = e.message; } },
  stop: () => { speechSynthesis.cancel(); if (isExtension) request({ type: 'speech:stop' }).catch(() => {}); },
  status: text => { status.textContent = text; }
});
async function act(action) {
  try {
    if (action === 'stop') { controller.stop(); return; }
    if (action === 'toggle') { focusEditor(); await controller.toggle(); return; }
    const position = controller.position(); if (position) await request({ type: 'progress:save', ...position });
    state = (await request({ type: 'state:get' })).state;
    if (!state.cues.length) throw new Error('Load and save reference text in Reference & settings first.');
    if (action === 'read') { if (isExtension) await request({ type: 'speech:read', offset: state.offset, revision: state.revision }); else await demoSpeak(controller.text, state.settings.rate); return; }
    state = (await request({ type: 'cue:jump', index: Math.max(0, Math.min(state.cues.length - 1, state.index + (action === 'next' ? 1 : -1))) })).state;
    focusEditor(); controller.show(sessionPayload(state));
  } catch (e) { status.textContent = e.message; status.classList.add('error'); }
}
document.querySelectorAll('[data-action]').forEach(button => button.addEventListener('click', () => act(button.dataset.action)));
select.addEventListener('change', async () => {
  try {
    const position = controller.position(); if (position) await request({ type: 'progress:save', ...position });
    state = (await request({ type: 'state:get' })).state;
    state = (await request({ type: 'essay:save', draft: { ...state, settings: { ...state.settings, chunkSize: Number(select.value) } } })).state;
    focusEditor(); controller.show(sessionPayload(state));
  } catch (e) { status.textContent = e.message; }
});
try {
  state = (await request({ type: 'state:get' })).state;
  if (!state.cues.length && !isExtension) state = (await request({ type: 'essay:save', draft: { title: 'Practice sample', text: SAMPLE, settings: state.settings } })).state;
  select.value = String(state.settings.chunkSize); controller.configure(state.settings);
  status.textContent = state.cues.length ? `Click the page and press ${state.settings.toggleKey}. Type the faint words by hand. No timer.` : 'Load and save reference text in Reference & settings first.';
} catch (e) { status.textContent = e.message; }
