import { request, isExtension } from './platform.js';
const $ = id => document.getElementById(id);
async function showVersion() {
  try {
    const manifest = isExtension ? chrome.runtime.getManifest() : await fetch(new URL('manifest.json', import.meta.url)).then(response => response.json());
    $('version').textContent = `v${manifest.version}`;
    $('version').title = `Extension version ${manifest.version}`;
    $('version').hidden = false;
  } catch { /* The local preview can still work without a manifest. */ }
}
showVersion();
let state;
const error = message => { $('popupError').textContent = message; $('popupError').hidden = !message; };
function render(value) {
  state = value; $('chunkSize').value = String(state.settings.chunkSize);
  $('keyHint').textContent = state.cues.length ? `${state.settings.toggleKey} · toggle` : 'Add reference text in Settings';
}
$('chunkSize').addEventListener('change', async () => {
  const chunkSize = Number($('chunkSize').value);
  $('chunkSize').disabled = true; $('saveStatus').textContent = ''; error('');
  try { render((await request({ type: 'settings:update', chunkSize })).state); $('saveStatus').textContent = 'Saved'; }
  catch (e) { if (state) render(state); error(e.message); }
  finally { $('chunkSize').disabled = false; }
});
$('setupLink').addEventListener('click', event => {
  if (!isExtension) return;
  event.preventDefault(); chrome.runtime.openOptionsPage(); window.close();
});
try {
  const data = await request({ type: 'state:get' }); render(data.state);
  $('chunkSize').disabled = false; error(data.lastError || '');
} catch (e) { error(e.message); }
if (isExtension) {
  try { const connection = await request({ type: 'document:connect' }); if (connection.connected && state) error(''); }
  catch (e) { error(e.message); }
}
